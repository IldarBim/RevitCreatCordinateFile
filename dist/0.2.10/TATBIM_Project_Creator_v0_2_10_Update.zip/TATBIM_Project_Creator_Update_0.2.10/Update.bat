@echo off
setlocal
chcp 65001 >nul
echo TATBIM Project Creator 0.2.10 - обновление
tasklist /FI "IMAGENAME eq Revit.exe" | find /I "Revit.exe" >nul && (echo Закройте Revit перед обновлением. & pause & exit /b 1)
set "TATBIM_FIX_DIR=%~dp0"
powershell -NoProfile -Command "$ErrorActionPreference='Stop'; try { $dst=Join-Path $env:APPDATA 'Autodesk\Revit\Addins\2022\TATBIM.ProjectCreator\TATBIM.ProjectCreator.dll'; $src=Join-Path $env:TATBIM_FIX_DIR 'TATBIM.ProjectCreator.dll'; if (-not (Test-Path -LiteralPath $dst)) { throw 'Установленный плагин не найден. Используйте install.bat из архива исходников.' }; $backup=$dst+'.backup-'+(Get-Date -Format 'yyyyMMdd-HHmmss-fff'); Copy-Item -LiteralPath $dst -Destination $backup -ErrorAction Stop; Copy-Item -LiteralPath $src -Destination $dst -Force -ErrorAction Stop; if ((Get-FileHash -LiteralPath $src).Hash -ne (Get-FileHash -LiteralPath $dst).Hash) { throw 'Контрольная сумма DLL не совпала' }; Write-Host 'Обновление установлено. Настройки сохранены.'; Write-Host ('Резервная копия: '+$backup) } catch { Write-Host $_.Exception.Message; exit 1 }"
if errorlevel 1 (pause & exit /b 1)
echo Запустите Revit 2022. В окне плагина должна быть версия 0.2.10.
pause
